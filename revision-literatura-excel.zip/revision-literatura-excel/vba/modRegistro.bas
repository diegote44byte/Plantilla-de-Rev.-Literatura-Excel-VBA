Attribute VB_Name = "modRegistro"
'===============================================================
'  Registro para Revisión de Literatura - macros
'  Hoja "Registro de fuente": formulario (etiquetas en B, datos en C)
'  Hoja "Literatura": base de datos (tabla tblLiteratura)
'  Cada etiqueta del formulario debe llamarse igual que el
'  encabezado de la columna en la tabla. Para agregar un campo:
'  agrega una fila al formulario (antes de la fila FILA_FIN) y una
'  columna con el mismo nombre en la tabla.
'===============================================================
Option Explicit

Private Const HOJA_FORM As String = "Registro de fuente"
Private Const HOJA_DATOS As String = "Literatura"
Private Const TABLA As String = "tblLiteratura"
Private Const CELDA_ID As String = "C6"
Private Const FILA_INI As Long = 8
Private Const FILA_FIN As Long = 24
Private Const COL_ETIQ As Long = 2
Private Const COL_VALOR As Long = 3
Private Const OBLIGATORIOS As String = "Autores|Año|Título"
Private Const TITULO_MSG As String = "Revisión de literatura"

'----------------------------- utilidades -----------------------------
Private Function HojaForm() As Worksheet
    Set HojaForm = ThisWorkbook.Worksheets(HOJA_FORM)
End Function

Private Function Tbl() As ListObject
    Set Tbl = ThisWorkbook.Worksheets(HOJA_DATOS).ListObjects(TABLA)
End Function

Private Function Etiqueta(ByVal fila As Long) As String
    Etiqueta = Trim$(CStr(HojaForm.Cells(fila, COL_ETIQ).Value))
End Function

Private Function ColumnaDe(ByVal nombre As String) As Long
    Dim lc As ListColumn
    ColumnaDe = 0
    If Len(nombre) = 0 Then Exit Function
    For Each lc In Tbl.ListColumns
        If StrComp(Trim$(lc.Name), nombre, vbTextCompare) = 0 Then
            ColumnaDe = lc.Index
            Exit Function
        End If
    Next lc
End Function

Private Function FilaDeCampo(ByVal nombre As String) As Long
    Dim f As Long
    FilaDeCampo = 0
    For f = FILA_INI To FILA_FIN
        If StrComp(Etiqueta(f), nombre, vbTextCompare) = 0 Then
            FilaDeCampo = f
            Exit Function
        End If
    Next f
End Function

Private Function ValorCampo(ByVal nombre As String) As String
    Dim f As Long
    f = FilaDeCampo(nombre)
    If f > 0 Then ValorCampo = Trim$(CStr(HojaForm.Cells(f, COL_VALOR).Value))
End Function

Private Function IDActual() As String
    IDActual = Trim$(CStr(HojaForm.Range(CELDA_ID).Value))
End Function

Private Function TablaVacia() As Boolean
    Dim t As ListObject
    Set t = Tbl
    If t.DataBodyRange Is Nothing Then
        TablaVacia = True
    ElseIf t.ListRows.Count = 1 Then
        TablaVacia = (Application.WorksheetFunction.CountA(t.ListRows(1).Range) = 0)
    Else
        TablaVacia = False
    End If
End Function

Private Function SiguienteID() As Long
    Dim t As ListObject
    Set t = Tbl
    If TablaVacia() Then
        SiguienteID = 1
    Else
        SiguienteID = CLng(Application.WorksheetFunction.Max(t.ListColumns(ColumnaDe("ID")).DataBodyRange)) + 1
    End If
End Function

Private Function NuevaFila() As ListRow
    Dim t As ListObject
    Set t = Tbl
    If Not t.DataBodyRange Is Nothing Then
        If t.ListRows.Count = 1 Then
            If Application.WorksheetFunction.CountA(t.ListRows(1).Range) = 0 Then
                Set NuevaFila = t.ListRows(1)
                Exit Function
            End If
        End If
    End If
    Set NuevaFila = t.ListRows.Add(AlwaysInsert:=True)
End Function

Private Function FilaPorID(ByVal id As String) As ListRow
    Dim t As ListObject, c As Range, i As Long
    Set FilaPorID = Nothing
    Set t = Tbl
    If Len(id) = 0 Or TablaVacia() Then Exit Function
    i = 0
    For Each c In t.ListColumns(ColumnaDe("ID")).DataBodyRange.Cells
        i = i + 1
        If Trim$(CStr(c.Value)) = id Then
            Set FilaPorID = t.ListRows(i)
            Exit Function
        End If
    Next c
End Function

Private Function ValidarObligatorios() As Boolean
    Dim campos() As String, i As Long, faltan As String, anio As String
    campos = Split(OBLIGATORIOS, "|")
    For i = LBound(campos) To UBound(campos)
        If Len(ValorCampo(campos(i))) = 0 Then faltan = faltan & vbLf & "   - " & campos(i)
    Next i
    If Len(faltan) > 0 Then
        MsgBox "Completa los campos obligatorios:" & faltan, vbExclamation, TITULO_MSG
        ValidarObligatorios = False
        Exit Function
    End If
    anio = ValorCampo("Año")
    If IsNumeric(anio) Then
        If CDbl(anio) < 1800 Or CDbl(anio) > Year(Date) + 1 Then
            If MsgBox("El año " & anio & " parece fuera de rango. ¿Continuar de todos modos?", _
                      vbQuestion + vbYesNo, TITULO_MSG) = vbNo Then Exit Function
        End If
    End If
    ValidarObligatorios = True
End Function

Private Function BuscarDuplicado(ByVal titulo As String, ByVal excluirID As String) As String
    Dim t As ListObject, cT As Long, cI As Long, r As Long, v As Variant
    BuscarDuplicado = ""
    Set t = Tbl
    If TablaVacia() Or Len(titulo) = 0 Then Exit Function
    cT = ColumnaDe("Título"): cI = ColumnaDe("ID")
    If cT = 0 Then Exit Function
    v = t.DataBodyRange.Value
    For r = 1 To UBound(v, 1)
        If StrComp(Trim$(CStr(v(r, cT))), titulo, vbTextCompare) = 0 Then
            If Trim$(CStr(v(r, cI))) <> excluirID Then
                BuscarDuplicado = Trim$(CStr(v(r, cI)))
                Exit Function
            End If
        End If
    Next r
End Function

Private Sub EscribirFila(ByVal lr As ListRow)
    Dim f As Long, col As Long, et As String
    For f = FILA_INI To FILA_FIN
        et = Etiqueta(f)
        If StrComp(et, "ID", vbTextCompare) <> 0 Then
            col = ColumnaDe(et)
            If col > 0 Then lr.Range.Cells(1, col).Value = HojaForm.Cells(f, COL_VALOR).Value
        End If
    Next f
End Sub

Private Sub LimpiarCampos()
    Dim f As Long
    For f = FILA_INI To FILA_FIN
        If ColumnaDe(Etiqueta(f)) > 0 Then HojaForm.Cells(f, COL_VALOR).ClearContents
    Next f
    HojaForm.Range(CELDA_ID).ClearContents
End Sub

Private Sub IrAlPrimerCampo()
    HojaForm.Activate
    HojaForm.Cells(FILA_INI, COL_VALOR).Select
End Sub

'Carga una fila de la tabla en el formulario
Private Sub CargarEnFormulario(ByVal lr As ListRow)
    Dim f As Long, col As Long
    Application.ScreenUpdating = False
    LimpiarCampos
    HojaForm.Range(CELDA_ID).Value = lr.Range.Cells(1, ColumnaDe("ID")).Value
    For f = FILA_INI To FILA_FIN
        col = ColumnaDe(Etiqueta(f))
        If col > 0 Then HojaForm.Cells(f, COL_VALOR).Value = lr.Range.Cells(1, col).Value
    Next f
    Application.ScreenUpdating = True
    IrAlPrimerCampo
End Sub

'Usado por el doble clic en la hoja Literatura
Public Sub CargarDesdeFilaHoja(ByVal filaHoja As Long)
    Dim t As ListObject, idx As Long
    Set t = Tbl
    If t.DataBodyRange Is Nothing Then Exit Sub
    idx = filaHoja - t.HeaderRowRange.Row
    If idx < 1 Or idx > t.ListRows.Count Then Exit Sub
    If Len(Trim$(CStr(t.ListRows(idx).Range.Cells(1, ColumnaDe("ID")).Value))) = 0 Then Exit Sub
    CargarEnFormulario t.ListRows(idx)
End Sub

'========================= MACROS DE LOS BOTONES =========================

Public Sub GuardarFuente()
    Dim lr As ListRow, nuevoID As Long, dup As String
    On Error GoTo ErrH
    If Len(IDActual()) > 0 Then
        If MsgBox("El formulario tiene cargada la fuente ID " & IDActual() & "." & vbLf & vbLf & _
                  "Para guardar cambios en ella usa el botón 'Actualizar'." & vbLf & _
                  "¿Quieres guardarla como una fuente NUEVA (copia)?", _
                  vbQuestion + vbYesNo, TITULO_MSG) = vbNo Then Exit Sub
    End If
    If Not ValidarObligatorios() Then Exit Sub
    dup = BuscarDuplicado(ValorCampo("Título"), "")
    If Len(dup) > 0 Then
        If MsgBox("Ya existe una fuente con el mismo título (ID " & dup & ")." & vbLf & _
                  "¿Guardarla de todos modos?", vbExclamation + vbYesNo, TITULO_MSG) = vbNo Then Exit Sub
    End If
    Application.ScreenUpdating = False
    nuevoID = SiguienteID()
    Set lr = NuevaFila()
    lr.Range.Cells(1, ColumnaDe("ID")).Value = nuevoID
    EscribirFila lr
    LimpiarCampos
    Application.ScreenUpdating = True
    IrAlPrimerCampo
    MsgBox "Fuente guardada con ID " & nuevoID & "." & vbLf & _
           "Total de fuentes registradas: " & Tbl.ListRows.Count, vbInformation, TITULO_MSG
    Exit Sub
ErrH:
    Application.ScreenUpdating = True
    MsgBox "No se pudo guardar la fuente: " & Err.Description, vbCritical, TITULO_MSG
End Sub

Public Sub ActualizarFuente()
    Dim lr As ListRow, id As String, dup As String
    On Error GoTo ErrH
    id = IDActual()
    If Len(id) = 0 Then
        MsgBox "No hay ninguna fuente cargada." & vbLf & _
               "Usa 'Buscar' (o doble clic sobre el ID en la hoja Literatura) para cargar una fuente y luego edítala.", _
               vbInformation, TITULO_MSG
        Exit Sub
    End If
    Set lr = FilaPorID(id)
    If lr Is Nothing Then
        MsgBox "No se encontró la fuente con ID " & id & ".", vbExclamation, TITULO_MSG
        Exit Sub
    End If
    If Not ValidarObligatorios() Then Exit Sub
    dup = BuscarDuplicado(ValorCampo("Título"), id)
    If Len(dup) > 0 Then
        If MsgBox("Otra fuente (ID " & dup & ") tiene el mismo título." & vbLf & _
                  "¿Actualizar de todos modos?", vbExclamation + vbYesNo, TITULO_MSG) = vbNo Then Exit Sub
    End If
    Application.ScreenUpdating = False
    EscribirFila lr
    LimpiarCampos
    Application.ScreenUpdating = True
    IrAlPrimerCampo
    MsgBox "Fuente ID " & id & " actualizada.", vbInformation, TITULO_MSG
    Exit Sub
ErrH:
    Application.ScreenUpdating = True
    MsgBox "No se pudo actualizar la fuente: " & Err.Description, vbCritical, TITULO_MSG
End Sub

Public Sub BuscarFuente()
    Dim t As ListObject, txt As String, v As Variant, r As Long
    Dim cI As Long, cA As Long, cY As Long, cT As Long
    Dim n As Long, lista As String, ultimo As Long
    On Error GoTo ErrH
    Set t = Tbl
    If TablaVacia() Then
        MsgBox "Todavía no hay fuentes registradas.", vbInformation, TITULO_MSG
        Exit Sub
    End If
    txt = Trim$(InputBox("Escribe el ID de la fuente, o una palabra del autor o del título:", TITULO_MSG))
    If Len(txt) = 0 Then Exit Sub

    If IsNumeric(txt) Then
        If Not FilaPorID(txt) Is Nothing Then
            CargarEnFormulario FilaPorID(txt)
            Exit Sub
        End If
    End If

    cI = ColumnaDe("ID"): cA = ColumnaDe("Autores"): cY = ColumnaDe("Año"): cT = ColumnaDe("Título")
    v = t.DataBodyRange.Value
    For r = 1 To UBound(v, 1)
        If InStr(1, CStr(v(r, cA)), txt, vbTextCompare) > 0 Or InStr(1, CStr(v(r, cT)), txt, vbTextCompare) > 0 Then
            n = n + 1
            ultimo = r
            If n <= 15 Then lista = lista & vbLf & "ID " & v(r, cI) & ":  " & v(r, cA) & " (" & v(r, cY) & ") - " & Left$(CStr(v(r, cT)), 60)
        End If
    Next r

    If n = 0 Then
        MsgBox "No se encontraron fuentes que coincidan con """ & txt & """.", vbInformation, TITULO_MSG
    ElseIf n = 1 Then
        CargarEnFormulario t.ListRows(ultimo)
    Else
        If n > 15 Then lista = lista & vbLf & "... y " & (n - 15) & " más."
        txt = Trim$(InputBox("Se encontraron " & n & " fuentes:" & lista & vbLf & vbLf & _
                             "Escribe el ID de la que quieres cargar:", TITULO_MSG))
        If Len(txt) = 0 Then Exit Sub
        If FilaPorID(txt) Is Nothing Then
            MsgBox "No existe el ID " & txt & ".", vbExclamation, TITULO_MSG
        Else
            CargarEnFormulario FilaPorID(txt)
        End If
    End If
    Exit Sub
ErrH:
    Application.ScreenUpdating = True
    MsgBox "Error al buscar: " & Err.Description, vbCritical, TITULO_MSG
End Sub

Public Sub EliminarFuente()
    Dim lr As ListRow, id As String, desc As String
    On Error GoTo ErrH
    id = IDActual()
    If Len(id) = 0 Then
        id = Trim$(InputBox("Escribe el ID de la fuente que deseas eliminar:", TITULO_MSG))
        If Len(id) = 0 Then Exit Sub
    End If
    Set lr = FilaPorID(id)
    If lr Is Nothing Then
        MsgBox "No se encontró la fuente con ID " & id & ".", vbExclamation, TITULO_MSG
        Exit Sub
    End If
    desc = CStr(lr.Range.Cells(1, ColumnaDe("Autores")).Value) & " (" & _
           CStr(lr.Range.Cells(1, ColumnaDe("Año")).Value) & ")" & vbLf & _
           CStr(lr.Range.Cells(1, ColumnaDe("Título")).Value)
    If MsgBox("¿Eliminar definitivamente esta fuente?" & vbLf & vbLf & "ID " & id & ": " & desc, _
              vbExclamation + vbYesNo + vbDefaultButton2, TITULO_MSG) = vbNo Then Exit Sub
    Application.ScreenUpdating = False
    If Tbl.ListRows.Count = 1 Then
        lr.Range.ClearContents
    Else
        lr.Delete
    End If
    If IDActual() = id Then LimpiarCampos
    Application.ScreenUpdating = True
    MsgBox "Fuente ID " & id & " eliminada.", vbInformation, TITULO_MSG
    Exit Sub
ErrH:
    Application.ScreenUpdating = True
    MsgBox "No se pudo eliminar la fuente: " & Err.Description, vbCritical, TITULO_MSG
End Sub

Public Sub LimpiarFormulario()
    LimpiarCampos
    IrAlPrimerCampo
End Sub

Public Sub IrALiteratura()
    With ThisWorkbook.Worksheets(HOJA_DATOS)
        .Activate
        .Range("A1").Select
    End With
End Sub

Public Sub IrARegistro()
    IrAlPrimerCampo
End Sub
